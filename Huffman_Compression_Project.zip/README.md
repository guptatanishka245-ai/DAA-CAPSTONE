# File Compression Using Huffman Coding

## Project overview
This Python project compresses and decompresses files using Huffman Coding, a lossless compression algorithm. It counts byte frequencies, builds a Huffman tree with a min-heap, generates prefix-free binary codes, writes the encoded stream to a binary file, and reconstructs the original file.

## Requirements
- Python 3.9 or newer
- No external libraries are required

## How to run
Open a terminal in this project folder.

### 1. Compress a text file
```bash
python main.py compress sample_files/input.txt
```
This creates `sample_files/input.txt.huff`.

### 2. View compression information
```bash
python main.py info sample_files/input.txt.huff
```

### 3. Decompress the file
```bash
python main.py decompress sample_files/input.txt.huff
```
This creates `sample_files/input.txt` only if the default output path is used; to avoid overwriting the sample, use:
```bash
python main.py decompress sample_files/input.txt.huff -o sample_files/restored.txt
```

### 4. Verify that the restored file is identical
Windows PowerShell:
```powershell
fc.exe /b sample_files/input.txt sample_files/restored.txt
```
If the files match, the command reports no differences.

## Project modules
- `build_huffman_tree()` — combines the two least-frequent nodes repeatedly.
- `generate_codes()` — traverses left as `0` and right as `1`.
- `compress_file()` — writes the header and packed encoded data.
- `decompress_file()` — rebuilds the tree from the frequency table and decodes the bits.
- `show_info()` — displays sizes and encoded information.

## Algorithm
1. Read the input file as bytes.
2. Count the frequency of each byte.
3. Insert each byte and its frequency into a min-priority queue.
4. Remove the two lowest-frequency nodes and combine them into a parent node.
5. Repeat until one root remains.
6. Traverse the tree to assign binary codes.
7. Replace each input byte with its code and pack bits into bytes.
8. Store a header containing the original size and frequency table.
9. During decoding, rebuild the same tree and traverse it according to each bit.

## Complexity analysis
Let `n` be the number of bytes in the input and `k` the number of distinct byte values (`k <= 256`).

| Operation | Time complexity |
|---|---:|
| Frequency counting | O(n) |
| Building the Huffman tree | O(k log k) |
| Generating codes | O(k) |
| Encoding | O(n) |
| Decoding | O(n) |
| Total compression | O(n + k log k) |
| Total decompression | O(n + k log k) |

Space complexity:
- Frequency table and Huffman tree: O(k)
- Encoded output: O(n) in the worst case
- Decoded output: O(n)
- Overall auxiliary/output space: O(n + k)

## Compression measurements
The program prints the exact original and compressed sizes for the file you run. Results depend on the input. Repeated text generally compresses better than random or already-compressed data. The compressed file includes a header, so very small files can become larger.

Compression percentage = `(compressed size / original size) × 100`

Space saved = `original size - compressed size`

## Limitations
- This implementation is intended as an educational project, not a production archive format.
- It compresses one file at a time.
- The header stores a frequency table, which adds overhead.
- Huffman coding is lossless: decompression restores the original bytes exactly.
