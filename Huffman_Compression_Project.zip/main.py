"""
Huffman File Compression
------------------------
Commands:
  python main.py compress sample_files/input.txt
  python main.py decompress sample_files/input.huff
  python main.py info sample_files/input.huff

The compressed file stores:
  1. Magic signature: HUF1
  2. Original file size (8 bytes)
  3. Number of distinct symbols (2 bytes)
  4. Frequency table: (symbol byte, frequency 8 bytes)
  5. Huffman-encoded bit stream, packed into bytes

This format supports all byte values and preserves the original file exactly.
"""

import argparse
import heapq
import os
import struct
from collections import Counter
from dataclasses import dataclass
from itertools import count

MAGIC = b"HUF1"


@dataclass
class Node:
    frequency: int
    symbol: int = None
    left: "Node" = None
    right: "Node" = None

    def is_leaf(self):
        return self.left is None and self.right is None


def build_huffman_tree(frequencies):
    """Build a Huffman tree using a min-priority queue."""
    if not frequencies:
        return None

    serial = count()
    heap = []
    for symbol, frequency in sorted(frequencies.items()):
        heapq.heappush(heap, (frequency, next(serial), Node(frequency, symbol)))

    # A single-symbol file needs no tree merge; it receives code '0'.
    if len(heap) == 1:
        return heap[0][2]

    while len(heap) > 1:
        f1, _, left = heapq.heappop(heap)
        f2, _, right = heapq.heappop(heap)
        parent = Node(f1 + f2, None, left, right)
        heapq.heappush(heap, (parent.frequency, next(serial), parent))

    return heap[0][2]


def generate_codes(root):
    """Return a dictionary mapping each byte value to its Huffman bit string."""
    codes = {}
    if root is None:
        return codes

    def visit(node, prefix):
        if node.is_leaf():
            codes[node.symbol] = prefix or "0"
            return
        visit(node.left, prefix + "0")
        visit(node.right, prefix + "1")

    visit(root, "")
    return codes


def pack_bits(bit_string):
    """Pack a string of 0/1 bits into bytes, padding the final byte with zeros."""
    output = bytearray()
    for start in range(0, len(bit_string), 8):
        chunk = bit_string[start:start + 8]
        valid = len(chunk)
        chunk = chunk.ljust(8, "0")
        output.append(int(chunk, 2))
    return bytes(output)


def unpack_bits(data, bit_count):
    """Convert packed bytes back to exactly bit_count bits."""
    bits = "".join(f"{byte:08b}" for byte in data)
    return bits[:bit_count]


def compress_file(input_path, output_path=None):
    with open(input_path, "rb") as file:
        raw = file.read()

    frequencies = Counter(raw)
    tree = build_huffman_tree(frequencies)
    codes = generate_codes(tree)

    encoded_bits = "".join(codes[byte] for byte in raw)
    packed_data = pack_bits(encoded_bits)

    if output_path is None:
        output_path = input_path + ".huff"

    # Header: signature, original size, symbol count, then frequency entries.
    with open(output_path, "wb") as output:
        output.write(MAGIC)
        output.write(struct.pack(">Q", len(raw)))
        output.write(struct.pack(">H", len(frequencies)))
        for symbol, frequency in sorted(frequencies.items()):
            output.write(struct.pack(">BQ", symbol, frequency))
        output.write(struct.pack(">Q", len(encoded_bits)))
        output.write(packed_data)

    original_size = len(raw)
    compressed_size = os.path.getsize(output_path)
    saved = original_size - compressed_size
    ratio = (compressed_size / original_size * 100) if original_size else 0

    print("\nCOMPRESSION COMPLETE")
    print(f"Input file       : {input_path}")
    print(f"Compressed file  : {output_path}")
    print(f"Original size    : {original_size} bytes")
    print(f"Compressed size  : {compressed_size} bytes")
    print(f"Space saved      : {saved} bytes")
    print(f"Compressed size  : {ratio:.2f}% of original")
    if saved < 0:
        print("Note: This small file became larger because the Huffman header adds overhead.")
    return output_path


def decompress_file(input_path, output_path=None):
    if output_path is None:
        output_path = input_path[:-5] if input_path.endswith(".huff") else input_path + ".decoded"

    with open(input_path, "rb") as file:
        if file.read(4) != MAGIC:
            raise ValueError("Invalid file: Huffman signature not found.")

        original_size = struct.unpack(">Q", file.read(8))[0]
        symbol_count = struct.unpack(">H", file.read(2))[0]

        frequencies = {}
        for _ in range(symbol_count):
            symbol, frequency = struct.unpack(">BQ", file.read(9))
            frequencies[symbol] = frequency

        bit_count = struct.unpack(">Q", file.read(8))[0]
        packed_data = file.read()

    if original_size == 0:
        decoded = b""
    else:
        tree = build_huffman_tree(frequencies)
        if tree is None:
            raise ValueError("Invalid compressed file: missing frequency table.")

        bits = unpack_bits(packed_data, bit_count)
        result = bytearray()

        if tree.is_leaf():
            result.extend([tree.symbol] * original_size)
        else:
            current = tree
            for bit in bits:
                current = current.left if bit == "0" else current.right
                if current.is_leaf():
                    result.append(current.symbol)
                    current = tree
                    if len(result) == original_size:
                        break

        if len(result) != original_size:
            raise ValueError("Could not decode file: data may be corrupted.")
        decoded = bytes(result)

    with open(output_path, "wb") as file:
        file.write(decoded)

    print("\nDECOMPRESSION COMPLETE")
    print(f"Compressed file  : {input_path}")
    print(f"Restored file    : {output_path}")
    print(f"Restored size    : {len(decoded)} bytes")
    print("Verification     : Original data restored successfully.")
    return output_path


def show_info(path):
    with open(path, "rb") as file:
        if file.read(4) != MAGIC:
            raise ValueError("Not a supported .huff file.")
        original_size = struct.unpack(">Q", file.read(8))[0]
        symbol_count = struct.unpack(">H", file.read(2))[0]
        for _ in range(symbol_count):
            file.read(9)
        bit_count = struct.unpack(">Q", file.read(8))[0]

    compressed_size = os.path.getsize(path)
    print("\nFILE INFORMATION")
    print(f"Original size       : {original_size} bytes")
    print(f"Compressed size     : {compressed_size} bytes")
    print(f"Encoded data bits   : {bit_count}")
    print(f"Distinct symbols    : {symbol_count}")
    if original_size:
        print(f"Compression ratio   : {compressed_size / original_size * 100:.2f}%")


def main():
    parser = argparse.ArgumentParser(description="Compress and decompress files using Huffman Coding.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    compress_parser = subparsers.add_parser("compress", help="Compress a file")
    compress_parser.add_argument("input", help="Path of the input file")
    compress_parser.add_argument("-o", "--output", help="Output compressed file path")

    decompress_parser = subparsers.add_parser("decompress", help="Decompress a .huff file")
    decompress_parser.add_argument("input", help="Path of the compressed file")
    decompress_parser.add_argument("-o", "--output", help="Output restored file path")

    info_parser = subparsers.add_parser("info", help="Display compressed file information")
    info_parser.add_argument("input", help="Path of the compressed file")

    args = parser.parse_args()
    if args.command == "compress":
        compress_file(args.input, args.output)
    elif args.command == "decompress":
        decompress_file(args.input, args.output)
    elif args.command == "info":
        show_info(args.input)


if __name__ == "__main__":
    main()
