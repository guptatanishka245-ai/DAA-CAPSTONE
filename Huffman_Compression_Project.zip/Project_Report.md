# PROJECT REPORT
## Project 3: File Compression Using Huffman Coding

### 1. Aim
To develop a file compression system using Huffman Coding that reduces the storage required for text files and restores the original file without data loss.

### 2. Problem statement
Text files contain characters that may occur with different frequencies. Storing every character with a fixed number of bits can use more space than necessary. Huffman Coding assigns shorter binary codes to frequently occurring characters and longer codes to less frequent characters.

### 3. Objectives
- Calculate the frequency of each character/byte.
- Construct a Huffman Tree using a min-priority queue.
- Generate unique prefix-free binary codes.
- Encode the input file and save it in compressed binary form.
- Decode the compressed file to recover the original content.
- Compare original and compressed file sizes.
- Analyse time and space complexity.

### 4. Tools and technology
- Programming language: Python 3
- Data structures: dictionary/frequency table, binary tree, min-heap, byte array
- Python modules: `heapq`, `collections`, `struct`, `argparse`, `os`

### 5. Working
The program reads the file in binary mode and counts how many times each byte occurs. Every distinct byte becomes a leaf node in a min-heap. The two nodes with the smallest frequencies are removed and joined under a new parent whose frequency is their sum. This continues until one root node remains.

The tree is traversed to generate codes: a left edge represents `0` and a right edge represents `1`. Each input byte is replaced with its code. The bits are packed into bytes and stored with a header containing the original file size and frequency table.

For decompression, the program reads the header, rebuilds the Huffman tree, and follows the encoded bits from the root. Whenever a leaf is reached, its byte is written to the output. The original file size is used to stop decoding at the correct point.

### 6. Algorithm
**Compression**
1. Read input bytes.
2. Count byte frequencies.
3. Build a min-heap of leaf nodes.
4. Repeatedly combine the two nodes with minimum frequency.
5. Generate codes by traversing the final tree.
6. Encode input bytes using the generated codes.
7. Pack bits into bytes and write the compressed file.

**Decompression**
1. Read the compressed file header.
2. Recreate the frequency table and Huffman tree.
3. Read the encoded bit stream.
4. Traverse left for `0` and right for `1`.
5. Output a byte whenever a leaf node is reached.
6. Stop after restoring the recorded original number of bytes.

### 7. Complexity analysis
Let `n` be the number of input bytes and `k` the number of distinct byte values.

| Operation | Time complexity |
|---|---|
| Frequency calculation | O(n) |
| Huffman tree construction | O(k log k) |
| Code generation | O(k) |
| Encoding | O(n) |
| Decoding | O(n) |
| Overall | O(n + k log k) |

Space complexity is O(k) for the frequency table and tree, plus O(n) for encoded/decoded data. Therefore, the overall space requirement is O(n + k).

### 8. Result and observation
The application reports the original size, compressed size, bytes saved, and compressed size as a percentage of the original. The exact values are produced when the program is executed and depend on the input file. Text with repeated patterns usually compresses more effectively. Very small files may become larger because the frequency table and file header add overhead.

### 9. Conclusion
The project successfully demonstrates lossless file compression using Huffman Coding. It uses frequency analysis and a min-heap to build an efficient prefix-code tree. The decompression process reconstructs the original file exactly. The project also demonstrates how data structures and algorithm complexity affect practical file compression.

### 10. How to execute
Run the following commands from the project directory:

```bash
python main.py compress sample_files/input.txt
python main.py info sample_files/input.txt.huff
python main.py decompress sample_files/input.txt.huff -o sample_files/restored.txt
```

To verify the restored file on Windows:

```powershell
fc.exe /b sample_files/input.txt sample_files/restored.txt
```
